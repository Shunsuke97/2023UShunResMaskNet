try:
    pass
except ImportError:
    pass

#!/bin/bash
apt-get -y install htop libglib2.0-0

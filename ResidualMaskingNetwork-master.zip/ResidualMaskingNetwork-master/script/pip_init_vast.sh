#!/bin/bash

pip install gpustat
pip install torch==1.2.0 torchvision
pip install future
pip install opencv-python
pip install imgaug
pip install pandas
pip install tensorboard==1.14
pip install sklearn
pip install natsort
pip install pytorchcv
pip install gputil
